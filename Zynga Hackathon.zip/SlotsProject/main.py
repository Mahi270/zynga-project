from Handler import start, execute

def run():
    start()
    execute()

if __name__ == '__main__':
    run()
    