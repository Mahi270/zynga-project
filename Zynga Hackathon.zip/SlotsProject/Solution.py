import cv2
from skimage.metrics import structural_similarity as ssim
import pytesseract
import re

class Solution:
    def __init__(self):
        pass
    
    def get_answer(self, problem):
        if "Set8" in problem:
            return self.process_set8(problem)
        elif "Set9" in problem:
            return self.process_set9(problem)
        else:
            return self.process_sets1to7(problem)
    
    def process_sets1to7(self, problem):
        main_image = cv2.imread(f'Problems/{problem}/Image.png')
        test_image1 = cv2.imread(f'Problems/{problem}/Test1.png')
        test_image2 = cv2.imread(f'Problems/{problem}/Test2.png')

        main_gray = cv2.cvtColor(main_image, cv2.COLOR_BGR2GRAY)
        test1_gray = cv2.cvtColor(test_image1, cv2.COLOR_BGR2GRAY)
        test2_gray = cv2.cvtColor(test_image2, cv2.COLOR_BGR2GRAY)

        main_gray_resized1 = cv2.resize(main_gray, (test1_gray.shape[1], test1_gray.shape[0]))
        main_gray_resized2 = cv2.resize(main_gray, (test2_gray.shape[1], test2_gray.shape[0]))

        similarity1 = ssim(main_gray_resized1, test1_gray)
        similarity2 = ssim(main_gray_resized2, test2_gray)

        return [round(similarity1 * 100, 2), round(similarity2 * 100, 2)]

    def process_set8(self, problem):
        test_image1 = cv2.imread(f'Problems/{problem}/Test1.png')
        test_image2 = cv2.imread(f'Problems/{problem}/Test2.png')

        total_win1 = self.extract_text(test_image1, "TOTAL WIN")
        total_win2 = self.extract_text(test_image2, "TOTAL WIN")

        return [total_win1, total_win2]

    def process_set9(self, problem):
        test_image1 = cv2.imread(f'Problems/{problem}/Test1.png')
        test_image2 = cv2.imread(f'Problems/{problem}/Test2.png')

        bet1 = self.extract_text(test_image1, "BET")
        bet2 = self.extract_text(test_image2, "BET")

        return [bet1, bet2]

    def extract_text(self, image, keyword):
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        try:
            text = pytesseract.image_to_string(gray)
        except pytesseract.TesseractError as e:
            print(f"OCR Error: {e}")
            return 0
        
        for line in text.split('\n'):
            if keyword in line:
                return self.extract_number_from_line(line)
        return 0

    def extract_number_from_line(self, line):
        numbers = re.findall(r'\d+', line)
        if numbers:
            return int(numbers[0])
        return 0
